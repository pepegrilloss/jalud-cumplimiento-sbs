<div class="jalud-login-wrapper">

    
    <div class="jalud-login-image-side">

        <div class="jalud-image-overlay"></div>

        <img src="<?php echo e(asset('JALUD.png')); ?>" alt="Fondo JALUD" class="jalud-bg-image"
            onerror="this.src='https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'">

        <div class="jalud-geo-circle jalud-geo-1"></div>
        <div class="jalud-geo-circle jalud-geo-2"></div>
        <div class="jalud-geo-circle jalud-geo-3"></div>

        <div class="jalud-brand-content">
            <div class="jalud-brand-badge">Cumplimiento SBS</div>
            <h2 class="jalud-brand-headline">
                Bienvenido al area de
                <span>Cumplimiento SBS</span>
            </h2>
            <p class="jalud-brand-sub">
                Gestiona y documenta los casos ROS.<br>
                Control, trazabilidad y cumplimiento normativo.
            </p>
            <div class="jalud-brand-dots">
                <span class="dot active"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </div>
    </div>

    
    <div class="jalud-login-form-side">

        <div class="jalud-particle jalud-p1"></div>
        <div class="jalud-particle jalud-p2"></div>
        <div class="jalud-particle jalud-p3"></div>

        <div class="jalud-form-container">

            <div class="jalud-logo-wrap">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo JALUD" class="jalud-logo"
                    onerror="this.src='https://ui-avatars.com/api/?name=JALUD&background=4f7942&color=fff&size=120'">
            </div>

            <div class="jalud-form-header">
                <h1 class="jalud-form-title">Iniciar Sesión</h1>
                <p class="jalud-form-subtitle">Ingresa tus credenciales para acceder al sistema</p>
            </div>

            <div class="jalud-divider">
                <span class="jalud-divider-line"></span>
                <span class="jalud-divider-icon">🔐</span>
                <span class="jalud-divider-line"></span>
            </div>
            
            <div class="jalud-fields-wrap">
                <?php if (isset($component)) { $__componentOriginald09a0ea6d62fc9155b01d885c3fdffb3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald09a0ea6d62fc9155b01d885c3fdffb3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.form.index','data' => ['wire:submit' => 'authenticate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:submit' => 'authenticate']); ?>
                    <?php echo e($this->form); ?>

                    <?php if (isset($component)) { $__componentOriginal742ef35d02cb00943edd9ad8ebf61966 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal742ef35d02cb00943edd9ad8ebf61966 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.form.actions','data' => ['actions' => $this->getCachedFormActions(),'fullWidth' => $this->hasFullWidthFormActions(),'class' => 'jalud-actions-wrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::form.actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['actions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->getCachedFormActions()),'full-width' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->hasFullWidthFormActions()),'class' => 'jalud-actions-wrap']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal742ef35d02cb00943edd9ad8ebf61966)): ?>
<?php $attributes = $__attributesOriginal742ef35d02cb00943edd9ad8ebf61966; ?>
<?php unset($__attributesOriginal742ef35d02cb00943edd9ad8ebf61966); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal742ef35d02cb00943edd9ad8ebf61966)): ?>
<?php $component = $__componentOriginal742ef35d02cb00943edd9ad8ebf61966; ?>
<?php unset($__componentOriginal742ef35d02cb00943edd9ad8ebf61966); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald09a0ea6d62fc9155b01d885c3fdffb3)): ?>
<?php $attributes = $__attributesOriginald09a0ea6d62fc9155b01d885c3fdffb3; ?>
<?php unset($__attributesOriginald09a0ea6d62fc9155b01d885c3fdffb3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald09a0ea6d62fc9155b01d885c3fdffb3)): ?>
<?php $component = $__componentOriginald09a0ea6d62fc9155b01d885c3fdffb3; ?>
<?php unset($__componentOriginald09a0ea6d62fc9155b01d885c3fdffb3); ?>
<?php endif; ?>
            </div>

            <div class="jalud-form-footer">
                <p>&copy; <?php echo e(date('Y')); ?> jalud-prestamos. Todos los derechos reservados.</p>
            </div>

        </div>
    </div>

    <style>
        /* 
           FIX PARA MODO OSCURO EN LOGIN 
           Aseguramos que los labels y textos sean visibles 
        */
        .dark .jalud-login-form-side {
            background-color: #111827 !important;
        }

        .dark .jalud-form-title {
            color: #ffffff !important;
        }

        .dark .jalud-form-subtitle, 
        .dark .jalud-form-footer p {
            color: #9ca3af !important;
        }

        /* Labels de Filament en modo oscuro */
        .dark .fi-fo-field-label {
            color: #e5e7eb !important;
        }

        /* Inputs de Filament en modo oscuro */
        .dark .fi-input-wrp {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        
        .dark .fi-input {
            color: #ffffff !important;
        }

        /* Asegurar visibilidad de labels específicos si son blancos por error */
        .dark label {
            color: #e5e7eb !important;
        }

        /* Ajustes para el contenedor principal en responsive */
        @media (max-width: 1024px) {
            .jalud-login-wrapper {
                flex-direction: column;
            }
            .jalud-login-image-side {
                display: none;
            }
            .jalud-login-form-side {
                width: 100%;
            }
        }
    </style>
</div>
<?php /**PATH C:\xampp\htdocs\jalud-cumplimiento\resources\views/filament/pages/auth/login.blade.php ENDPATH**/ ?>