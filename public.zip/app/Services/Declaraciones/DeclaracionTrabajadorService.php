<?php

namespace App\Services\Declaraciones;

use App\Enums\Declaraciones\EstadoDeclaracion;
use App\Models\DeclaracionTrabajador;
use Carbon\CarbonInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Rules\DocumentoIdentidadValido;

class DeclaracionTrabajadorService
{
    public const RELACIONES = ['estudios', 'educacionEscolar', 'otrosEstudios', 'experienciasLaborales', 'capacitaciones', 'bienesInmuebles', 'vehiculos', 'otrosBienes', 'inversiones', 'obligaciones'];

    public function finalizar(DeclaracionTrabajador $declaracion): DeclaracionTrabajador
    {
        abort_if($declaracion->Estado !== EstadoDeclaracion::BORRADOR->value, 422, 'La declaración ya fue finalizada.');
        $declaracion->load(self::RELACIONES);
        $this->validar($declaracion);

        return DB::transaction(function () use ($declaracion): DeclaracionTrabajador {
            $declaracion->forceFill([
                'Estado' => EstadoDeclaracion::FINALIZADO->value,
                'FinalizadoPorID' => auth()->id(),
                'FinalizadoEn' => now(),
            ])->save();
            return $declaracion->refresh()->load(self::RELACIONES);
        });
    }

    public function nuevaVersion(DeclaracionTrabajador $origen): DeclaracionTrabajador
    {
        abort_if($origen->Estado !== EstadoDeclaracion::FINALIZADO->value, 422, 'Solo se versionan declaraciones finalizadas.');
        $origen->load(self::RELACIONES);

        return DB::transaction(function () use ($origen): DeclaracionTrabajador {
            $copia = $origen->replicate();
            $copia->NumeroVersion = (int) DeclaracionTrabajador::withoutGlobalScope('sede')->where('TrabajadorID', $origen->TrabajadorID)->max('NumeroVersion') + 1;
            $copia->Estado = EstadoDeclaracion::BORRADOR->value;
            $copia->CreadoPorID = auth()->id() ?? $origen->CreadoPorID;
            $copia->ActualizadoPorID = auth()->id() ?? $origen->ActualizadoPorID ?? $origen->CreadoPorID;
            $copia->FinalizadoPorID = null;
            $copia->FinalizadoEn = null;
            $copia->save();

            foreach (self::RELACIONES as $relacion) {
                foreach ($origen->{$relacion} as $detalle) {
                    $nuevo = $detalle->replicate();
                    $nuevo->DeclaracionTrabajadorID = $copia->getKey();
                    $nuevo->save();
                }
            }
            return $copia->load(self::RELACIONES);
        });
    }

    public static function experienciasUltimosDosAnios(Collection $experiencias, CarbonInterface $fechaContratacion): Collection
    {
        $desde = $fechaContratacion->copy()->subYears(2)->startOfDay();
        $hasta = $fechaContratacion->copy()->endOfDay();
        return $experiencias->filter(fn ($e) => $e->FechaInicio->lte($hasta) && ($e->FechaConclusion === null || $e->FechaConclusion->gte($desde)))
            ->sortByDesc('FechaInicio')->values();
    }

    private function validar(DeclaracionTrabajador $d): void
    {
        $data = $d->toArray();
        $data['experiencias'] = $d->experienciasLaborales->toArray();
        Validator::make($data, [
            'FechaContratacion' => ['required', 'date'], 'Nombres' => ['required'], 'ApellidoPaterno' => ['required'],
            'TipoDocumento' => ['required'], 'NumeroDocumento' => ['required', new DocumentoIdentidadValido($d->TipoDocumento)], 'EstadoCivil' => ['required'],
            'ConyugeNombres' => [Rule::requiredIf(in_array($d->EstadoCivil, ['CASADO', 'CONVIVIENTE'], true))],
            'ConyugeApellidos' => [Rule::requiredIf(in_array($d->EstadoCivil, ['CASADO', 'CONVIVIENTE'], true))],
            'CodigoOcupacion' => ['required'], 'Cargo' => ['required'], 'DomicilioVia' => ['required'],
            'DomicilioDistrito' => ['required'], 'DomicilioProvincia' => ['required'], 'DomicilioDepartamento' => ['required'],
            'DetalleAntecedentesPoliciales' => [Rule::requiredIf((bool) $d->TieneAntecedentesPoliciales)],
            'DetalleAntecedentesPenales' => [Rule::requiredIf((bool) $d->TieneAntecedentesPenales)],
            'CondicionViviendaOtra' => [Rule::requiredIf($d->CondicionVivienda === 'OTRA')],
            'CiudadSuscripcion' => ['required'], 'FechaDeclaracion' => ['required', 'date'],
            'RemuneracionBrutaMensual' => ['numeric', 'min:0'], 'IngresoEjercicioIndividual' => ['numeric', 'min:0'], 'OtrosIngresosMensuales' => ['numeric', 'min:0'],
            'experiencias.*.FechaInicio' => ['required', 'date'],
            'experiencias.*.FechaConclusion' => ['nullable', 'date', 'after_or_equal:experiencias.*.FechaInicio'],
        ], [], [
            'ConyugeNombres' => 'nombres del cónyuge/conviviente', 'ConyugeApellidos' => 'apellidos del cónyuge/conviviente',
        ])->validate();
    }
}
