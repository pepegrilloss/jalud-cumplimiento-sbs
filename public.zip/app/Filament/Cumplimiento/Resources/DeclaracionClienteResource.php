<?php

namespace App\Filament\Cumplimiento\Resources;

use App\Enums\Declaraciones\EstadoCivil;
use App\Enums\Declaraciones\EstadoDeclaracion;
use App\Enums\Declaraciones\TipoDocumentoIdentidad;
use App\Filament\Cumplimiento\Resources\DeclaracionClienteResource\Pages;
use App\Models\Cliente;
use App\Models\DeclaracionCliente;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class DeclaracionClienteResource extends Resource
{
    protected static ?string $model = DeclaracionCliente::class;
    protected static ?string $navigationIcon = 'heroicon-o-user-group';
    protected static ?string $navigationGroup = 'Declaraciones juradas';
    protected static ?string $navigationLabel = 'Clientes';
    protected static ?string $modelLabel = 'declaración de cliente';
    protected static ?string $pluralModelLabel = 'Declaraciones de clientes';
    protected static ?string $slug = 'declaraciones-clientes';
    protected static ?int $navigationSort = 20;

    public static function form(Form $form): Form
    {
        return $form->schema([Forms\Components\Wizard::make([
            Forms\Components\Wizard\Step::make('Datos generales')->icon('heroicon-o-user')->schema(self::generales()),
            Forms\Components\Wizard\Step::make('PEP')->icon('heroicon-o-shield-exclamation')->schema(self::pep()),
            Forms\Components\Wizard\Step::make('Beneficiario')->icon('heroicon-o-users')->schema(self::beneficiario()),
            Forms\Components\Wizard\Step::make('Revisión')->icon('heroicon-o-clipboard-document-check')->schema([
                Forms\Components\Placeholder::make('revision')->hiddenLabel()->content('Verifique las respuestas PEP, el beneficiario y el origen de fondos antes de finalizar.'),
                Forms\Components\TextInput::make('NumeroCuentaFinanciera')->label('N.º de cuenta financiera usada para procesar la transacción'),
                Forms\Components\DatePicker::make('FechaDeclaracion')->label('Fecha de declaración')->required()->default(now()),
            ])->columns(2),
            Forms\Components\Wizard\Step::make('Documento')->icon('heroicon-o-document-arrow-down')->schema([
                Forms\Components\Placeholder::make('documento_info')->hiddenLabel()->content('Al finalizar se habilitará la generación de la Declaración Jurada de conocimiento del cliente.'),
            ]),
        ])->columnSpanFull()]);
    }

    private static function generales(): array
    {
        return [
            Forms\Components\Section::make('Cliente')->schema([
                Forms\Components\Select::make('ClienteID')->label('Cliente')->options(fn()=>Cliente::query()->where('Activo',true)->limit(500)->pluck('NombresApellidos','ClienteID'))->searchable()->required()->live()->disabledOn('edit')
                    ->createOptionForm([
                        Forms\Components\TextInput::make('DNI')->label('Documento')->required(), Forms\Components\TextInput::make('Nombres')->required(),
                        Forms\Components\TextInput::make('ApellidoPaterno')->required(), Forms\Components\TextInput::make('ApellidoMaterno'),
                        Forms\Components\Select::make('Sexo')->options(['M'=>'Masculino','F'=>'Femenino'])->required(), Forms\Components\TextInput::make('Domicilio'),
                    ])->createOptionUsing(fn(array $data)=>Cliente::create($data+['NombresApellidos'=>'TEMPORAL','Estado'=>'NO OBSERVADO','UsuarioRegistro'=>auth()->user()?->username,'FechaRegistro'=>now(),'Activo'=>true])->getKey())
                    ->afterStateUpdated(function($state,Forms\Set $set):void{$c=Cliente::find($state);if(!$c)return;$set('Nombres',$c->Nombres ?: $c->NombresApellidos);$set('Apellidos',trim("{$c->ApellidoPaterno} {$c->ApellidoMaterno}"));$set('NumeroDocumento',$c->DNI);$set('DomicilioVia',$c->Domicilio);$set('ConyugeConviviente',$c->ConyugeNombresApellidos);}),
                Forms\Components\TextInput::make('Nombres')->required(), Forms\Components\TextInput::make('Apellidos')->required(),
                Forms\Components\Select::make('TipoDocumento')->label('Tipo de documento')->options(TipoDocumentoIdentidad::opciones())->default('DNI')->required(),
                Forms\Components\TextInput::make('NumeroDocumento')->label('Número de documento')->required()->rules(fn(Forms\Get $get)=>[new \App\Rules\DocumentoIdentidadValido($get('TipoDocumento'))]),
                Forms\Components\TextInput::make('Nacionalidad'), Forms\Components\Select::make('EstadoCivil')->label('Estado civil')->options(EstadoCivil::opciones())->required()->live(),
                Forms\Components\TextInput::make('ConyugeConviviente')->label('Cónyuge o conviviente')->required(fn(Forms\Get $get)=>in_array($get('EstadoCivil'),['CASADO','CONVIVIENTE'],true))->visible(fn(Forms\Get $get)=>in_array($get('EstadoCivil'),['CASADO','CONVIVIENTE'],true)),
            ])->columns(3),
            Forms\Components\Section::make('Domicilio')->schema([
                Forms\Components\TextInput::make('DomicilioVia')->label('Jr. / Av. / Calle / Pasaje / Óvalo')->required()->columnSpan(2), Forms\Components\TextInput::make('DomicilioNumero')->label('N.º'),
                Forms\Components\TextInput::make('DomicilioInterior')->label('Dpto.-Int. N.º'), Forms\Components\TextInput::make('DomicilioZona')->label('Urb. / Complejo / Zona / Sector')->columnSpan(2),
                Forms\Components\TextInput::make('DomicilioDistrito')->label('Distrito')->required(), Forms\Components\TextInput::make('DomicilioProvincia')->label('Provincia')->required(), Forms\Components\TextInput::make('DomicilioDepartamento')->label('Departamento')->required(),
            ])->columns(4),
            Forms\Components\Section::make('Contacto y relación')->schema([
                Forms\Components\TextInput::make('Ocupacion')->label('Ocupación')->required(), Forms\Components\TextInput::make('TelefonoFijo')->label('Teléfono fijo')->tel(),
                Forms\Components\TextInput::make('Celular')->tel(), Forms\Components\TextInput::make('Correo')->label('Correo electrónico')->email(),
                Forms\Components\Textarea::make('PropositoRelacion')->label('Propósito de la relación con el sujeto obligado')->required()->columnSpanFull(),
            ])->columns(4),
        ];
    }

    private static function pep(): array
    {
        $estados=['SI_SOY'=>'Sí soy','SI_HE_SIDO'=>'Sí he sido','NO_SOY'=>'No soy','NO_HE_SIDO'=>'No he sido'];
        return [
            Forms\Components\Section::make('10.1. Persona Expuesta Políticamente')->schema([
                Forms\Components\Radio::make('EstadoPep')->label('¿Es o ha sido PEP?')->options($estados)->required()->live()->inline(),
                Forms\Components\Radio::make('EstadoColaboradorAutoridad')->label('¿Ha sido colaborador directo de la máxima autoridad?')->options($estados)->required()->inline(),
                Forms\Components\TextInput::make('PepCargo')->label('Cargo')->required(fn(Forms\Get $get)=>in_array($get('EstadoPep'),['SI_SOY','SI_HE_SIDO'],true))->visible(fn(Forms\Get $get)=>in_array($get('EstadoPep'),['SI_SOY','SI_HE_SIDO'],true)),
                Forms\Components\TextInput::make('PepInstitucion')->label('Institución')->required(fn(Forms\Get $get)=>in_array($get('EstadoPep'),['SI_SOY','SI_HE_SIDO'],true))->visible(fn(Forms\Get $get)=>in_array($get('EstadoPep'),['SI_SOY','SI_HE_SIDO'],true)),
            ])->columns(2),
            Forms\Components\Repeater::make('pepFamiliares')->relationship()->label('10.2. Familiares de la persona PEP')->visible(fn(Forms\Get $get)=>in_array($get('EstadoPep'),['SI_SOY','SI_HE_SIDO'],true))->schema([
                Forms\Components\TextInput::make('Nombres')->required(), Forms\Components\TextInput::make('Apellidos')->required(), Forms\Components\TextInput::make('Parentesco')->required(),
            ])->columns(3)->addActionLabel('Agregar familiar')->orderColumn('Orden')->defaultItems(0),
            Forms\Components\Section::make('10.3. Pariente de PEP')->schema([
                Forms\Components\Toggle::make('EsParientePep')->label('¿Es pariente de PEP?')->live(),
                Forms\Components\Repeater::make('pepRelacionados')->relationship()->label('PEP relacionados')->visible(fn(Forms\Get $get)=>(bool)$get('EsParientePep'))->schema([
                    Forms\Components\TextInput::make('Nombres')->required(), Forms\Components\TextInput::make('Apellidos')->required(), Forms\Components\TextInput::make('Parentesco')->required(),
                ])->columns(3)->addActionLabel('Agregar PEP relacionado')->orderColumn('Orden')->defaultItems(0)->columnSpanFull(),
            ]),
        ];
    }

    private static function beneficiario(): array
    {
        return [Forms\Components\Section::make('Identidad del beneficiario de la operación')->schema([
            Forms\Components\Radio::make('TipoBeneficiario')->options(['YO_MISMO'=>'Yo mismo','TERCERO_NATURAL'=>'Tercero persona natural','PERSONA_JURIDICA'=>'Persona jurídica','ENTE_JURIDICO'=>'Ente jurídico'])->required()->live()->inline(),
            Forms\Components\Textarea::make('OrigenFondos')->label('Origen de los fondos/activos involucrados')->required()->columnSpanFull(),
            Forms\Components\Fieldset::make('Tercero persona natural')->visible(fn(Forms\Get $get)=>$get('TipoBeneficiario')==='TERCERO_NATURAL')->schema([
                Forms\Components\TextInput::make('TerceroNombresApellidos')->label('Nombres y apellidos')->required(),
                Forms\Components\Select::make('TerceroTipoDocumento')->label('Tipo de documento')->options(TipoDocumentoIdentidad::opciones())->required(), Forms\Components\TextInput::make('TerceroNumeroDocumento')->label('Número')->required()->rules(fn(Forms\Get $get)=>[new \App\Rules\DocumentoIdentidadValido($get('TerceroTipoDocumento'))]),
                Forms\Components\Radio::make('TerceroRepresentacion')->label('Representación')->options(['ESCRITURA_PUBLICA'=>'Poder por Escritura Pública','MANDATO'=>'Mandato'])->required()->inline(),
                Forms\Components\Radio::make('TerceroEstadoPep')->label('PEP')->options(['SI_ES'=>'Sí es','SI_HA_SIDO'=>'Sí ha sido','NO_ES'=>'No es','NO_HA_SIDO'=>'No ha sido'])->required()->live()->inline(),
                Forms\Components\TextInput::make('TerceroPepCargo')->label('Cargo')->visible(fn(Forms\Get $get)=>in_array($get('TerceroEstadoPep'),['SI_ES','SI_HA_SIDO'],true)),
                Forms\Components\TextInput::make('TerceroPepInstitucion')->label('Institución')->visible(fn(Forms\Get $get)=>in_array($get('TerceroEstadoPep'),['SI_ES','SI_HA_SIDO'],true)),
            ])->columns(2),
            Forms\Components\Fieldset::make('Persona jurídica / ente jurídico')->visible(fn(Forms\Get $get)=>in_array($get('TipoBeneficiario'),['PERSONA_JURIDICA','ENTE_JURIDICO'],true))->schema([
                Forms\Components\TextInput::make('EntidadRazonSocial')->label('Denominación o razón social')->required(), Forms\Components\TextInput::make('EntidadRucRegistro')->label('RUC o registro equivalente')->required(),
                Forms\Components\Radio::make('EntidadRepresentacion')->label('Representación')->options(['PODER_ACTA'=>'Poder por acta','ESCRITURA_PUBLICA'=>'Poder por escritura pública','MANDATO'=>'Mandato'])->required()->inline(),
                Forms\Components\TextInput::make('BeneficiarioFinalNombres')->label('Nombres y apellidos del beneficiario final')->required(),
            ])->columns(2),
        ])->columns(2)];
    }

    public static function table(Table $table): Table
    {
        return $table->defaultSort('created_at','desc')->columns([
            Tables\Columns\TextColumn::make('NombreCompleto')->label('Cliente')->searchable(['Nombres','Apellidos']), Tables\Columns\TextColumn::make('NumeroDocumento')->label('Documento')->searchable(),
            Tables\Columns\TextColumn::make('NumeroVersion')->label('Versión')->badge(), Tables\Columns\TextColumn::make('FechaDeclaracion')->label('Fecha')->date('d/m/Y'),
            Tables\Columns\TextColumn::make('Estado')->badge()->formatStateUsing(fn($s)=>EstadoDeclaracion::tryFrom($s)?->label()??$s)->color(fn($s)=>$s==='FINALIZADO'?'success':'warning'),
            Tables\Columns\IconColumn::make('documento')->label('Declaración')->state(fn($r)=>$r->documentos()->where('TipoDocumento','CLIENTE_REGIMEN_GENERAL')->exists())->boolean(),
        ])->actions([Tables\Actions\ViewAction::make(),Tables\Actions\EditAction::make()->visible(fn($r)=>$r->Estado==='BORRADOR')])->bulkActions([]);
    }

    public static function getPages(): array { return ['index'=>Pages\ListDeclaracionesCliente::route('/'),'create'=>Pages\CreateDeclaracionCliente::route('/create'),'view'=>Pages\ViewDeclaracionCliente::route('/{record}'),'edit'=>Pages\EditDeclaracionCliente::route('/{record}/edit')]; }
}
