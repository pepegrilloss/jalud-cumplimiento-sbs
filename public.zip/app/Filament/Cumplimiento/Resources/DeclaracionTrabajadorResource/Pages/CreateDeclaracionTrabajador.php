<?php
namespace App\Filament\Cumplimiento\Resources\DeclaracionTrabajadorResource\Pages;
use App\Filament\Cumplimiento\Resources\DeclaracionTrabajadorResource;
use App\Models\DeclaracionTrabajador;
use App\Models\Trabajador;
use Filament\Resources\Pages\CreateRecord;
class CreateDeclaracionTrabajador extends CreateRecord
{
    protected static string $resource = DeclaracionTrabajadorResource::class;
    protected function mutateFormDataBeforeCreate(array $data): array { $t=Trabajador::findOrFail($data['TrabajadorID']); $data['SedeID']=$t->SedeID; $data['NumeroVersion']=(int) DeclaracionTrabajador::withoutGlobalScope('sede')->where('TrabajadorID',$t->getKey())->max('NumeroVersion')+1; $data['Estado']='BORRADOR'; return $data; }
    protected function getCreateFormAction(): \Filament\Actions\Action { return parent::getCreateFormAction()->label('Guardar borrador'); }
}
