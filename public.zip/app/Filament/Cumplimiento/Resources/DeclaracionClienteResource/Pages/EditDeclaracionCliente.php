<?php
namespace App\Filament\Cumplimiento\Resources\DeclaracionClienteResource\Pages;
use App\Filament\Cumplimiento\Resources\DeclaracionClienteResource;
use App\Services\Declaraciones\DeclaracionClienteService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;
class EditDeclaracionCliente extends EditRecord { protected static string $resource=DeclaracionClienteResource::class; protected function getHeaderActions():array{return[Actions\ViewAction::make(),Actions\Action::make('finalizar')->label('Finalizar declaración')->icon('heroicon-o-lock-closed')->color('success')->requiresConfirmation()->visible(fn()=>$this->record->Estado==='BORRADOR')->authorize('finalizar')->action(function(){app(DeclaracionClienteService::class)->finalizar($this->record);Notification::make()->success()->title('Declaración finalizada')->send();$this->redirect(static::$resource::getUrl('view',['record'=>$this->record]));})];} protected function getSaveFormAction():Actions\Action{return parent::getSaveFormAction()->label('Guardar borrador');} }
