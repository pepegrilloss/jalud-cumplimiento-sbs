<?php

namespace App\Observers;

use App\Models\LogAuditoria;
use Illuminate\Database\Eloquent\Model;

class DeclaracionAuditObserver
{
    public function created(Model $model): void { $this->registrar('CREAR', $model, [], $model->getAttributes()); }
    public function updated(Model $model): void { $this->registrar('ACTUALIZAR', $model, $model->getOriginal(), $model->getChanges()); }
    public function deleted(Model $model): void { $this->registrar('ELIMINAR', $model, $model->getOriginal(), []); }

    private function registrar(string $accion, Model $model, array $anterior, array $nuevo): void
    {
        if (! auth()->id()) { return; }
        $sedeId = $model->SedeID ?? $model->declaracion?->SedeID ?? null;
        LogAuditoria::withoutEvents(fn () => LogAuditoria::create([
            'user_id' => auth()->id(), 'accion' => $accion, 'modelo' => class_basename($model), 'modelo_id' => $model->getKey(),
            'old_values' => $this->sinSensibles($anterior), 'new_values' => $this->sinSensibles($nuevo),
            'ip_address' => request()?->ip(), 'user_agent' => mb_substr((string) request()?->userAgent(), 0, 255),
            'platform' => PHP_OS_FAMILY, 'created_at' => now(), 'SedeID' => $sedeId,
        ]));
    }

    private function sinSensibles(array $valores): array
    {
        return collect($valores)->except(['password', 'remember_token'])->all();
    }
}
