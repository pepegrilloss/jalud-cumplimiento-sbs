<?php

namespace App\Models;

use App\Enums\Declaraciones\EstadoDeclaracion;
use App\Traits\BelongsToSede;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Validation\ValidationException;

class DeclaracionCliente extends Model
{
    use BelongsToSede;
    protected $table = 'dj_declaraciones_cliente';
    protected $primaryKey = 'DeclaracionClienteID';
    protected $guarded = ['DeclaracionClienteID'];
    protected $casts = ['FechaDeclaracion' => 'date', 'FinalizadoEn' => 'datetime', 'EsParientePep' => 'boolean'];

    protected static function booted(): void
    {
        static::creating(function (self $d): void { $d->CreadoPorID ??= auth()->id(); $d->ActualizadoPorID ??= auth()->id(); $d->Estado ??= EstadoDeclaracion::BORRADOR->value; });
        static::updating(function (self $d): void {
            if ($d->getOriginal('Estado') === EstadoDeclaracion::FINALIZADO->value) {
                throw ValidationException::withMessages(['Estado' => 'Una declaración finalizada es inmutable. Cree una nueva versión.']);
            }
            $d->ActualizadoPorID = auth()->id();
        });
    }

    public function cliente(): BelongsTo { return $this->belongsTo(Cliente::class, 'ClienteID', 'ClienteID'); }
    public function pepFamiliares(): HasMany { return $this->hasMany(PepFamiliar::class, 'DeclaracionClienteID', 'DeclaracionClienteID')->orderBy('Orden'); }
    public function pepRelacionados(): HasMany { return $this->hasMany(PepRelacionado::class, 'DeclaracionClienteID', 'DeclaracionClienteID')->orderBy('Orden'); }
    public function documentos(): HasMany { return $this->hasMany(DeclaracionDocumento::class, 'DeclaracionClienteID', 'DeclaracionClienteID'); }
    public function getNombreCompletoAttribute(): string { return trim("{$this->Nombres} {$this->Apellidos}"); }
}
