<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
abstract class DetalleDeclaracionCliente extends Model { protected $primaryKey = 'ID'; protected $guarded = ['ID']; public function declaracion(): BelongsTo { return $this->belongsTo(DeclaracionCliente::class, 'DeclaracionClienteID', 'DeclaracionClienteID'); } }
