<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

abstract class DetalleDeclaracionTrabajador extends Model
{
    protected $primaryKey = 'ID';
    protected $guarded = ['ID'];
    public function declaracion(): BelongsTo { return $this->belongsTo(DeclaracionTrabajador::class, 'DeclaracionTrabajadorID', 'DeclaracionTrabajadorID'); }
}
